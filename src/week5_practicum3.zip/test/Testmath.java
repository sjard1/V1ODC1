package test;

public class Testmath {
private int ah;

public Testmath(int a){
ah = a;
}
	
	{int a = 147 % 11;}
	
	System.out.println("a");
	
}
