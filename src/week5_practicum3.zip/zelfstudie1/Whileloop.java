package zelfstudie1;

public class Whileloop {
	
	public static void main(String[] args){
		
	int sum = 0;	
	int i = 0;
	
	while (i <= 39) {
		sum += i++;
	}
 System.out.println("De totale waarde is: " + sum);
}
}
