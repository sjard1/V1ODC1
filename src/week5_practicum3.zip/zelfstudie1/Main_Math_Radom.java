package zelfstudie1;

public class Main_Math_Radom {
	

public static void main(String[] args) {
double number = Math.random();

System.out.println(number);
}
}