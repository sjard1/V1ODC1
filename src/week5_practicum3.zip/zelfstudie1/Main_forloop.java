package zelfstudie1;

public class Main_forloop {
	public static void main(String[] args){
		for (int i = 1 ; i<11 ; i++){
			System.out.println("Getal is: " + i);
	}
	}
}
