package zelfstudie1;

public class Main_whileloop {
public static void main(String[] args){
	int count = 1;
	while (count < 11){
		System.out.println("tellen is "+ count);
		count++;
	}
	}
}
