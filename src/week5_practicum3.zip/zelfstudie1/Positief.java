package zelfstudie1;

public class Positief {

}
