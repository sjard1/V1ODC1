package week4_1_practica;

public class Goed {

}
