package week4_practicum2;

public class KamerType {

}
