package week1_opracht_bank;

public class Main {
	public static void main(String[]argm){
		Rekening r1 = new Rekening(124);
	

	System.out.println(r1.toString());
	}
}
