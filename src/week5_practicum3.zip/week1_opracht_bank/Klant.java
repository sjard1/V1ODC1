package week1_opracht_bank;

public class Klant {

}
