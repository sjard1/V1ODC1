package week2_practicum3;

public class Leerling {
	
 private String naam;
 private double cijfer;
 
 public Leerling(String nm){
	 naam = nm;
 }
 
 public String getNaam(){return naam;}
 public double getCijfer(){return cijfer;}
 
 public void setCijfer(double c){
	 cijfer = c;
 }
 
 public String toString(){
	 String s = naam + cijfer;
	 return s;
 }
}
