package week4_practicum1;

public interface Goed {

	public double huidigeWaarde();
}
