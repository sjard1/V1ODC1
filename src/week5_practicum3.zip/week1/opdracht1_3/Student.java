package week1.opdracht1_3;

public class Student {

	private String naam;
	
	
	public Student(String nm)
	{
		
	nm = naam;
	}
	
}

