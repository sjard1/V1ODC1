package week1.opdracht1_3;

public class Main {
	public static void main(String[] argms){
	
	Student s1 = new Student("pieter");
		}
}
