package week1.opdracht1_5;

public class Main {
public static void main(String[] argm){
	