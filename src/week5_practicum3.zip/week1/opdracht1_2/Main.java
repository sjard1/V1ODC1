package week1.opdracht1_2;

public class Main {   
	public static void main(String[] arg) {
		Klant k1 = new Klant("Jan", "Nijenoord 1", "Utrecht");
		Klant k2 = new Klant("Wim", "Oudenoord 340", "Utrecht");

}
}
